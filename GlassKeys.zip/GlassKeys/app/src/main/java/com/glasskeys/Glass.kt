package com.glasskeys

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.View

class Theme(
    val id: String,
    val title: String,
    val bgTop: Int,
    val bgBottom: Int,
    val blobs: IntArray,
    val text: Int,
    val dark: Boolean,
    val accent: Int
)

object Themes {
    private fun c(s: String) = Color.parseColor(s)

    val all = listOf(
        Theme("ocean", "Океан", c("#0B1B3A"), c("#0A0E1C"),
            intArrayOf(c("#3D7BFF"), c("#9B5CFF"), c("#18C8D6")), Color.WHITE, true, c("#5B8CFF")),
        Theme("aurora", "Аврора", c("#0F2A24"), c("#120B24"),
            intArrayOf(c("#2EE6A6"), c("#B45CFF"), c("#3D7BFF")), Color.WHITE, true, c("#35D6A0")),
        Theme("sunset", "Закат", c("#2A1220"), c("#140A1A"),
            intArrayOf(c("#FF6B6B"), c("#FFB347"), c("#B45CFF")), Color.WHITE, true, c("#FF7A6B")),
        Theme("graphite", "Графит", c("#1D1E22"), c("#0C0C0F"),
            intArrayOf(c("#6B7280"), c("#3D7BFF"), c("#4B5563")), Color.WHITE, true, c("#7C8CFF")),
        Theme("light", "Светлая", c("#DCE8FF"), c("#F2E6FF"),
            intArrayOf(c("#7AA8FF"), c("#FFA8D6"), c("#9FE6D0")), c("#111322"), false, c("#4C7DFF"))
    )

    fun get(id: String) = all.firstOrNull { it.id == id } ?: all[0]
}

object Glass {
    fun dp(ctx: Context, v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.resources.displayMetrics)

    private fun layer(ctx: Context, r: Float, topA: Int, botA: Int, strokeA: Int, tint: Int): GradientDrawable {
        val g = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.argb(topA, Color.red(tint), Color.green(tint), Color.blue(tint)),
                Color.argb(botA, Color.red(tint), Color.green(tint), Color.blue(tint))
            )
        )
        g.cornerRadius = dp(ctx, r)
        g.setStroke(dp(ctx, 1f).toInt().coerceAtLeast(1), Color.argb(strokeA, 255, 255, 255))
        return g
    }

    /** Стеклянная плашка: полупрозрачный градиент + светлая обводка. */
    fun bg(ctx: Context, t: Theme, radiusDp: Float, accent: Boolean = false): Drawable {
        val normal: Drawable
        val pressed: Drawable
        if (accent) {
            normal = layer(ctx, radiusDp, 0xA8, 0x68, 0x90, t.accent)
            pressed = layer(ctx, radiusDp, 0xD8, 0x98, 0xC0, t.accent)
        } else if (t.dark) {
            normal = layer(ctx, radiusDp, 0x38, 0x14, 0x60, Color.WHITE)
            pressed = layer(ctx, radiusDp, 0x70, 0x3C, 0x90, Color.WHITE)
        } else {
            normal = layer(ctx, radiusDp, 0xB8, 0x78, 0xE8, Color.WHITE)
            pressed = layer(ctx, radiusDp, 0xFF, 0xC8, 0xFF, Color.WHITE)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }
}

/** Клавиша: рисует основной символ и маленькую подсказку (долгое нажатие). */
class KeyView(ctx: Context, var label: String, var sub: String?, private val color: Int, private val sizeSp: Float) :
    View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val dm = resources.displayMetrics
        p.color = color
        p.alpha = 255
        var size = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sizeSp, dm)
        p.textSize = size
        val maxW = width - Glass.dp(context, 8f)
        val tw = p.measureText(label)
        if (tw > maxW && tw > 0f) {
            size *= maxW / tw
            p.textSize = size
        }
        val fm = p.fontMetrics
        c.drawText(label, width / 2f, height / 2f - (fm.ascent + fm.descent) / 2f, p)
        sub?.let {
            p.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 9f, dm)
            p.alpha = 140
            c.drawText(it, width - Glass.dp(context, 9f), Glass.dp(context, 13f), p)
        }
    }
}

/** Подложка клавиатуры: градиент + размытые цветные пятна, сквозь которые «просвечивает» стекло. */
class BackdropView(ctx: Context) : View(ctx) {
    private var theme = Themes.get("ocean")
    private var alphaPct = 100
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bgShader: Shader? = null
    private var blobShaders: List<Pair<Shader, FloatArray>> = emptyList()

    fun apply(t: Theme, opacityPct: Int) {
        theme = t
        alphaPct = opacityPct
        build()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        build()
    }

    private fun build() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        bgShader = LinearGradient(0f, 0f, 0f, h, theme.bgTop, theme.bgBottom, Shader.TileMode.CLAMP)
        val r = maxOf(w, h) * 0.55f
        val pos = listOf(floatArrayOf(0.12f, 0.25f), floatArrayOf(0.85f, 0.40f), floatArrayOf(0.50f, 1.0f))
        val list = mutableListOf<Pair<Shader, FloatArray>>()
        for ((i, pt) in pos.withIndex()) {
            val col = theme.blobs[i % theme.blobs.size]
            val a = if (theme.dark) 0x99 else 0xAA
            val sh = RadialGradient(
                pt[0] * w, pt[1] * h, r,
                Color.argb(a, Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                Shader.TileMode.CLAMP
            )
            list.add(sh to pt)
        }
        blobShaders = list
        line.color = Color.argb(if (theme.dark) 0x50 else 0xA0, 255, 255, 255)
        line.strokeWidth = Glass.dp(context, 1f)
    }

    override fun onDraw(c: Canvas) {
        val a = (255 * alphaPct / 100)
        paint.alpha = a
        paint.shader = bgShader
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        for ((sh, _) in blobShaders) {
            paint.shader = sh
            paint.alpha = a
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        }
        paint.shader = null
        c.drawLine(0f, 0f, width.toFloat(), 0f, line)
    }
}
