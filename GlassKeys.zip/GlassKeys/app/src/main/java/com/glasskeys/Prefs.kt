package com.glasskeys

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Доступные раскладки. */
object Layouts {
    val names = linkedMapOf(
        "ru" to "Русский",
        "en" to "English",
        "uk" to "Українська",
        "de" to "Deutsch",
        "fr" to "Français",
        "es" to "Español"
    )

    /** Языки для перевода (код MyMemory -> название). */
    val targets = linkedMapOf(
        "en" to "English", "ru" to "Русский", "uk" to "Українська", "de" to "Deutsch",
        "fr" to "Français", "es" to "Español", "it" to "Italiano", "pt" to "Português",
        "tr" to "Türkçe", "pl" to "Polski", "zh-CN" to "中文", "ja" to "日本語",
        "ko" to "한국어", "ar" to "العربية", "hi" to "हिन्दी", "kk" to "Қазақша"
    )

    fun rows(lang: String): List<String> = when (lang) {
        "ru" -> listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
        "uk" -> listOf("йцукенгшщзхї", "фівапролджє", "ячсмитьбю")
        "de" -> listOf("qwertzuiopü", "asdfghjklöä", "yxcvbnmß")
        "fr" -> listOf("azertyuiop", "qsdfghjklm", "wxcvbn")
        "es" -> listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm")
        else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    }

    fun isCyrillic(lang: String) = lang == "ru" || lang == "uk"

    /** Тег языка для LanguageTool. */
    fun ltTag(lang: String) = when (lang) {
        "ru" -> "ru-RU"; "en" -> "en-US"; "uk" -> "uk-UA"; "de" -> "de-DE"
        "fr" -> "fr"; "es" -> "es"; else -> "auto"
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("glass_keys", Context.MODE_PRIVATE)

    fun langs(c: Context): List<String> {
        val l = sp(c).getString("langs", "ru,en")!!.split(",").filter { it in Layouts.names }
        return if (l.isEmpty()) listOf("en") else l
    }

    fun setLangs(c: Context, l: List<String>) =
        sp(c).edit().putString("langs", l.joinToString(",")).apply()

    fun currentLang(c: Context): String {
        val cur = sp(c).getString("cur", "") ?: ""
        val l = langs(c)
        return if (cur in l) cur else l[0]
    }

    fun setCurrentLang(c: Context, v: String) = sp(c).edit().putString("cur", v).apply()

    fun target(c: Context): String = sp(c).getString("target", "en") ?: "en"
    fun setTarget(c: Context, v: String) = sp(c).edit().putString("target", v).apply()

    fun theme(c: Context): String = sp(c).getString("theme", "ocean") ?: "ocean"
    fun setTheme(c: Context, v: String) = sp(c).edit().putString("theme", v).apply()

    /** Непрозрачность подложки, 40..100 (%). */
    fun opacity(c: Context): Int = sp(c).getInt("opacity", 100)
    fun setOpacity(c: Context, v: Int) = sp(c).edit().putInt("opacity", v).apply()

    /** Высота клавиши, dp. */
    fun keyHeight(c: Context): Int = sp(c).getInt("kh", 50)
    fun setKeyHeight(c: Context, v: Int) = sp(c).edit().putInt("kh", v).apply()

    fun haptic(c: Context) = sp(c).getBoolean("haptic", true)
    fun setHaptic(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptic", v).apply()

    fun autoCap(c: Context) = sp(c).getBoolean("autocap", true)
    fun setAutoCap(c: Context, v: Boolean) = sp(c).edit().putBoolean("autocap", v).apply()

    fun clipEnabled(c: Context) = sp(c).getBoolean("clip", true)
    fun setClipEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("clip", v).apply()

    fun clipRaw(c: Context): String = sp(c).getString("clips", "[]") ?: "[]"
    fun setClipRaw(c: Context, v: String) = sp(c).edit().putString("clips", v).apply()
}

class ClipItem(val text: String, var pinned: Boolean)

/** История буфера обмена (хранится локально на устройстве). */
object ClipStore {
    private const val MAX = 50

    fun load(c: Context): MutableList<ClipItem> {
        val out = mutableListOf<ClipItem>()
        try {
            val arr = JSONArray(Prefs.clipRaw(c))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(ClipItem(o.getString("t"), o.optBoolean("p", false)))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(c: Context, list: List<ClipItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.text).put("p", it.pinned)) }
        Prefs.setClipRaw(c, arr.toString())
    }

    fun add(c: Context, text: String) {
        val list = load(c)
        val old = list.firstOrNull { it.text == text }
        val pinned = old?.pinned ?: false
        list.removeAll { it.text == text }
        list.add(0, ClipItem(text, pinned))
        // лимит только для незакреплённых
        while (list.count { !it.pinned } > MAX) {
            val idx = list.indexOfLast { !it.pinned }
            list.removeAt(idx)
        }
        save(c, list)
    }
}
