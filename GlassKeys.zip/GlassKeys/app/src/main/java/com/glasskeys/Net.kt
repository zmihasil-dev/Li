package com.glasskeys

import android.text.Html
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Исправление ошибок — LanguageTool (api.languagetool.org),
 * перевод — MyMemory (api.mymemory.translated.net). Оба бесплатные, без ключей, но с лимитами.
 */
object Net {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 12000
        c.setRequestProperty("User-Agent", "GlassKeys/1.0")
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return text
    }

    // ---------- Исправление ----------

    fun fix(text: String, lang: String): String {
        var body = "text=${enc(text)}&language=${enc(lang)}"
        if (lang == "auto") body += "&preferredVariants=${enc("en-US,de-DE,pt-PT,ca-ES")}"
        val json = JSONObject(request("https://api.languagetool.org/v2/check", body))
        val matches = json.getJSONArray("matches")

        class Fix(val off: Int, val len: Int, val rep: String)

        val fixes = mutableListOf<Fix>()
        for (i in 0 until matches.length()) {
            val m = matches.getJSONObject(i)
            val reps = m.getJSONArray("replacements")
            if (reps.length() == 0) continue
            val type = m.optJSONObject("rule")?.optString("issueType") ?: ""
            if (type == "style" || type == "register") continue
            fixes.add(Fix(m.getInt("offset"), m.getInt("length"), reps.getJSONObject(0).getString("value")))
        }
        fixes.sortByDescending { it.off }
        val sb = StringBuilder(text)
        var lastStart = Int.MAX_VALUE
        for (f in fixes) {
            if (f.off + f.len > lastStart) continue // пересекается с уже применённой правкой
            if (f.off < 0 || f.off + f.len > sb.length) continue
            sb.replace(f.off, f.off + f.len, f.rep)
            lastStart = f.off
        }
        return sb.toString()
    }

    // ---------- Перевод ----------

    private fun chunks(text: String): List<String> {
        val parts = Regex("[^.!?\\n]*[.!?]+\\s*|[^.!?\\n]+\\s*|\\n+").findAll(text).map { it.value }.toList()
        val out = mutableListOf<String>()
        val buf = StringBuilder()
        fun flush() {
            if (buf.isNotEmpty()) { out.add(buf.toString()); buf.setLength(0) }
        }
        for (p in parts) {
            var s = p
            while (s.length > 450) {
                var cut = s.lastIndexOf(' ', 450)
                if (cut < 100) cut = 450
                flush()
                out.add(s.substring(0, cut))
                s = s.substring(cut)
            }
            if (buf.length + s.length > 450) flush()
            buf.append(s)
        }
        flush()
        return out
    }

    fun translate(text: String, from: String, to: String): String {
        val sb = StringBuilder()
        for (ch in chunks(text)) {
            val core = ch.trim()
            if (core.isEmpty()) { sb.append(ch); continue }
            val lead = ch.takeWhile { it.isWhitespace() }
            val trail = ch.takeLastWhile { it.isWhitespace() }
            val url = "https://api.mymemory.translated.net/get?q=${enc(core)}&langpair=${enc("$from|$to")}"
            val json = JSONObject(request(url, null))
            val status = json.optInt("responseStatus", 200)
            if (status != 200) throw RuntimeException("status $status")
            var t = json.getJSONObject("responseData").getString("translatedText")
            t = Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString().trim()
            sb.append(lead).append(t).append(trail)
        }
        return sb.toString()
    }

    /** Определяем язык исходного текста по алфавиту и текущей раскладке. */
    fun detectSource(text: String, layout: String): String {
        val letters = text.count { it.isLetter() }
        val cyr = text.count { it in 'а'..'я' || it in 'А'..'Я' || it == 'ё' || it == 'Ё' || it in 'і'..'ї' }
        return if (letters > 0 && cyr * 2 > letters) {
            if (layout == "uk") "uk" else "ru"
        } else {
            if (Layouts.isCyrillic(layout)) "en" else layout
        }
    }
}
