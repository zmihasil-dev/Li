package com.glasskeys

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(32))
        }
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)

        fun title(t: String) = TextView(this).apply {
            text = t
            textSize = 13f
            alpha = 0.6f
            setPadding(0, dp(22), 0, dp(6))
        }

        fun label(t: String) = TextView(this).apply {
            text = t
            textSize = 15f
            setPadding(0, dp(6), 0, dp(2))
        }

        col.addView(TextView(this).apply {
            text = "Glass Keys"
            textSize = 28f
        })
        col.addView(TextView(this).apply {
            text = "Клавиатура в стиле жидкого стекла"
            alpha = 0.7f
        })

        // --- подключение
        col.addView(title("ПОДКЛЮЧЕНИЕ"))
        status = TextView(this).apply { textSize = 15f }
        col.addView(status)
        col.addView(Button(this).apply {
            text = "1. Включить клавиатуру"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "2. Выбрать как основную"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        // --- языки
        col.addView(title("ЯЗЫКИ РАСКЛАДКИ"))
        val enabled = Prefs.langs(this).toMutableList()
        Layouts.names.forEach { (code, name) ->
            col.addView(CheckBox(this).apply {
                text = name
                isChecked = code in enabled
                setOnCheckedChangeListener { b, checked ->
                    if (checked) {
                        if (code !in enabled) enabled.add(code)
                    } else {
                        if (enabled.size <= 1) {
                            b.isChecked = true
                            return@setOnCheckedChangeListener
                        }
                        enabled.remove(code)
                    }
                    Prefs.setLangs(this@SettingsActivity, enabled.toList())
                }
            })
        }

        // --- перевод
        col.addView(title("ПЕРЕВОДЧИК (кнопка 🌐)"))
        col.addView(label("Переводить на:"))
        val codes = Layouts.targets.keys.toList()
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(
                this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item,
                Layouts.targets.values.toList()
            )
            setSelection(codes.indexOf(Prefs.target(this@SettingsActivity)).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    Prefs.setTarget(this@SettingsActivity, codes[pos])
                }

                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })

        // --- оформление
        col.addView(title("ОФОРМЛЕНИЕ"))
        val group = RadioGroup(this)
        Themes.all.forEach { t ->
            group.addView(RadioButton(this).apply {
                text = t.title
                id = View.generateViewId()
                isChecked = Prefs.theme(this@SettingsActivity) == t.id
                setOnClickListener { Prefs.setTheme(this@SettingsActivity, t.id) }
            })
        }
        col.addView(group)

        col.addView(label("Непрозрачность подложки (ниже — больше «стекла» и размытия фона)"))
        col.addView(SeekBar(this).apply {
            max = 60
            progress = Prefs.opacity(this@SettingsActivity) - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Prefs.setOpacity(this@SettingsActivity, p + 40)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        col.addView(label("Высота клавиш"))
        col.addView(SeekBar(this).apply {
            max = 28
            progress = Prefs.keyHeight(this@SettingsActivity) - 36
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Prefs.setKeyHeight(this@SettingsActivity, p + 36)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        // --- поведение
        col.addView(title("ПОВЕДЕНИЕ"))
        fun sw(text: String, value: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
            this.text = text
            isChecked = value
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }
        col.addView(sw("Вибрация при нажатии", Prefs.haptic(this)) { Prefs.setHaptic(this, it) })
        col.addView(sw("Заглавная буква в начале предложения", Prefs.autoCap(this)) { Prefs.setAutoCap(this, it) })
        col.addView(sw("История буфера обмена", Prefs.clipEnabled(this)) { Prefs.setClipEnabled(this, it) })

        // --- проверка
        col.addView(title("ПРОВЕРКА"))
        col.addView(EditText(this).apply {
            hint = "Нажмите сюда и пишите"
            minLines = 3
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        col.addView(TextView(this).apply {
            text = "Подсказки:\n" +
                    "• 📋 — буфер обмена (📌 закрепить, ✕ удалить)\n" +
                    "• ✨ — исправить ошибки в выделенном тексте или во всём поле\n" +
                    "• 🌐 — перевести выделенное или всё поле\n" +
                    "• ↩ — отменить последнее исправление/перевод\n" +
                    "• Долгое нажатие на букву верхнего ряда — цифра (на русской «х» — ё)\n" +
                    "• Двойной пробел — точка; двойное нажатие ⇧ — Caps Lock\n" +
                    "• Кнопка с кодом языка (RU/EN) переключает раскладку\n\n" +
                    "Исправление и перевод отправляют текст на серверы LanguageTool и MyMemory. " +
                    "В полях паролей эти функции отключены."
            alpha = 0.75f
            setPadding(0, dp(20), 0, 0)
        })
    }

    override fun onResume() {
        super.onResume()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val def = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        status.text = when {
            !enabled -> "● Клавиатура ещё не включена"
            !def.startsWith(packageName) -> "● Включена, но не выбрана основной"
            else -> "● Готово: Glass Keys — основная клавиатура"
        }
    }
}
